import background from "./background.png";
import shadow1 from "./shadow.png";
import speaker from "./cb2.png";
import background2 from "./background_1.jpg";
import photo1 from "./photo1.jpeg";
import rulesforlife from "./11-rules-for-life.png";
import logo from "./logo.png";
import dilysip from "./daily-sip.jpg";
import degital_gold from "./degital_gold.webp";
import mutualfund from "./mutual-fund.webp";
import FixedDeposits from "./FixedDeposits.png";
import HealthInsurance from "./HealthInsurance.webp";
import RBIBonds from "./RBIBonds.webp";
import TaxSavingStrategies from "./TaxSavingStrategies.webp";
import DematAccountServices from "./DematAccountServices.png";
import RetirementPlanning from "./RetirementPlanning.jpg";
import EducationLoans from "./EducationLoans.jpeg";
import WhatsApp_icon from "./WhatsApp_icon.png";

export {
    background,
    shadow1,
    speaker,
    background2,
    photo1,
    rulesforlife,
    logo,
    dilysip,
    degital_gold,
    mutualfund,
    FixedDeposits,
    HealthInsurance,
    RBIBonds,
    TaxSavingStrategies,
    DematAccountServices,
    RetirementPlanning,
    EducationLoans,
    WhatsApp_icon
}